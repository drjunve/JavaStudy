package ex04controlstatement;

public class QuIfElseChange {

	public static void main(String[] args) {
		int num1=50, num2=100;

		if(num1>num2) {
			System.out.println(num1);
		}
		else {
			System.out.println(num2);
		}

		if(num1>num2) {
			System.out.println(num1-num2);
		}
		else {
			System.out.println(num2-num1);
		}
		
	}

}
