package ex04controlstatement;

public class QuIfMerge {

	public static void main(String[] args) {
		int num = 120;
		 if (num > 0 && (num%2)==0) {
				System.out.println("양수이면서 짝수");
		 }
	}

}
