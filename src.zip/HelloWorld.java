
public class HelloWorld {

	public static void main(String[] args) {
		//문자(char)를 작성할 때는 싱글 쿼테이션을 사용한다.
		System.out.println('A');
		//문자열(String)을 작성할 때는 더블 커테이션을 사용한다.
		System.out.println("AB");
		System.out.println("Hello World");
		System.out.println("안녕? 자바야..!!");
	}

}